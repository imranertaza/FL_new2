/* Add Custom Code Jquery
 ========================================================*/
$(document).ready(function(){
	// jQuery methods go here...
	 
 });